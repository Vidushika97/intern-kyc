<template>
  <div id="app">
    <!-- <HeaderView/> -->
    <router-view/>
    <!-- <SignUpload></SignUpload> -->
    <!-- <FormSignup></FormSignup> -->
    <!-- <PreviewForm></PreviewForm> -->
    <!-- <LoginModal></LoginModal> -->
    <!-- <SuccessModal></SuccessModal> -->
    <!-- <OtpModal></OtpModal> -->
    <!-- <FooterView/> -->
  </div>
</template>

<script>

// import FooterView from './components/FooterView.vue';
// import HeaderView from './components/HeaderView.vue';
// import FormSignup from './components/FormSignup.vue';
// import SignUpload from './components/SignUpload.vue';
// import PreviewForm from './components/PreviewForm.vue';
// import LoginModal from './components/LoginModal.vue';
// import OtpModal from './components/OtpModal.vue';
// import SuccessModal from './components/SuccessModal.vue';




export default {
  name : "App",
  components:{
    //  HeaderView,
    //  FooterView,
    //  FormSignup,
    //  SignUpload,
    // PreviewForm,
    // LoginModal,
    // OtpModal,
    // SuccessModal,

     
  }
  

}
</script>

<style>

</style>